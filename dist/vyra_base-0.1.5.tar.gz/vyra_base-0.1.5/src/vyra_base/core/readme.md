# Core

The core of each V.Y.R.A. module is the base class which will be used in later implementations as virtual parent class and does also implement some basics that could be used within each module at moduleclass, manufaction or specific level

