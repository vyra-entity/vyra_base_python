from vyra_base.storage.storage import Storage


class RedisAccess(Storage):
    pass