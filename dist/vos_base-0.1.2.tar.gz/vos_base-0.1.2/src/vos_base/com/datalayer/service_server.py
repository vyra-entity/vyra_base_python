
import rclpy
from dataclasses import dataclass

from rclpy.service import Service as rclService
from typing import Any
from typing import Callable
from typing import NoReturn
from typing import Union

from vos_base.com.datalayer.node import VOSNode

def _base_callback(*args, **kwargs) -> NoReturn:
    raise NotImplementedError("No execute callback provided for action server.")


@dataclass
class ServiceInfo:
    name: str = 'vos_service_server'
    type: Any = None
    callback: Callable = _base_callback
    service: Union[rclService, None] = None

class VOSServiceServer:
    """
    Base class for ROS2 services.
    This class will be factory created to implement specific service functionality.
    """

    def __init__(self, serviceInfo: ServiceInfo, node: VOSNode) -> None:
        self.service_info: ServiceInfo = serviceInfo
        self._node: VOSNode = node
    
    def create_service(self, callback: Callable) -> None:
        """
        Create a service in the ROS2 node.
        This method should be called to register the service with the ROS2 node.
        """
        self._node.get_logger().info(f"Creating service: {self.service_info.name}")
        if not self.service_info.type:
            raise ValueError("Service type must be provided.")
        
        if not self.service_info.name:
            raise ValueError("Service name must be provided.")
        
        self.service_info.service = self._node.create_service(
            self.service_info.type, 
            self.service_info.name, 
            self.callback
        )

    def callback(self, request, response)-> None:
        """
        Add a callback to the service.
        This method should be overridden in subclasses to provide specific functionality.
        """
        self._node.get_logger().info(f"Received request on {self.service_info.name}")

        try:
            self.service_info.callback(request, response)
        except:
            self._node.get_logger().error(f"Error in service callback for {self.service_info.name}")
        
        return response