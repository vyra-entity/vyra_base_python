import json

from .file_lock import get_lock_for_file, release_lock_for_file

from pathlib import Path
from aiopath import AsyncPath
from typing import Union

class FileReader:
    """ File reader.

        Reads file content from locally stored files into the module.
    """
    
    @classmethod    
    async def open_json_file(
        cls, config_file: Path, config_default: Path=Path('')) -> any: 
        """ Reads a json file

            To ensure cross platform compatibility. We open json files per se 
            with utf8-sig encoding
            
            Args:
                config_file (str): JSON formatted file.
                config_default (str) : JSON files as a default configuration 
                                       for the module
        """
        try:
            lock = await get_lock_for_file(config_file)
            async with lock:
                async with AsyncPath(str(config_file)).open(mode='r', 
                                                encoding='utf-8') as file:
                    json_content = json.loads(await file.read())
                    if json_content:
                        return json_content
                    else:
                        async with AsyncPath(str(config_default)) \
                                    .open(mode='r', encoding='utf-8-sig') as file:
                            await AsyncPath(str(config_file)).write_text(str(file))
                        return json.loads(await file.read())
            release_lock_for_file(config_file)
        except (IOError, UnicodeDecodeError, json.decoder.JSONDecodeError, 
                 TypeError, FileNotFoundError) as error:
                if error == IOError():
                    raise IOError('An unexpected io error occured!')
                if error == UnicodeDecodeError('', b'', 0, 0, ''):  
                    raise UnicodeDecodeError(
                        'A decoding error occured!', error, 0, 0, '') # type: ignore
                if error == json.decoder.JSONDecodeError('', '', 0): 
                    raise json.decoder.JSONDecodeError('JSON decoding error:', '', 0)
                if error == TypeError():
                    raise TypeError("An unexpected type error uccured!")
                if error == FileNotFoundError():
                    raise FileNotFoundError("File not found error!")

     
    @classmethod    
    async def open_markdown_file(cls, config_file: Path, config_default='') -> str:
        """ Reads a markdown file
            
        Args:
            config_file (str)    : JSON formatted file.
            config_default (str) : JSON files as a default configuration 
                                   for the module
        """
        try:  
            lock = await get_lock_for_file(config_file)
            async with lock:
                async with AsyncPath(str(config_file)) \
                            .open(mode='r', encoding='utf-8') as file:
                    content = await file.read()
                    if content:
                        return content
                    else:
                        async with AsyncPath(str(config_default)) \
                                    .open(mode='r', encoding='utf-8-sig') as file:
                            await AsyncPath(str(config_file)).write_text(str(file))
                        return await file.read()
            release_lock_for_file(config_file)
        except (IOError, UnicodeDecodeError, json.decoder.JSONDecodeError, 
                 TypeError, FileNotFoundError) as error:
            
            if error == IOError():
                raise IOError('An unexpected io error occured!')
            if error == UnicodeDecodeError(None, None, None, None, None): # type: ignore
                raise UnicodeDecodeError('A decoding error occured!', None, 0, 0, '') # type: ignore
            if error == json.decoder.JSONDecodeError(None, None, None): # type: ignore
                raise json.decoder.JSONDecodeError('JSON decoding error.', '', 0)
            if error == TypeError():
                raise TypeError("An unexpected type error uccured!")
            if error == FileNotFoundError():
                raise FileNotFoundError("File not found error!")
        finally:
            return ''
     
    @classmethod 
    async def open_env_file(cls, config_file: Path) -> list[str]:
        try:
            lock = await get_lock_for_file(config_file)
            async with lock:
                env_content: list = []
                async with AsyncPath(str(config_file)) \
                            .open(mode='r', encoding='utf-8-sig') as file:
                    content: str = await file.read()
                    for line in content.split():
                        env_content.append(line.split('=', 1))
                return env_content
            release_lock_for_file(config_file)
        except (IOError, TypeError, FileNotFoundError) as error:
            if error == IOError():
                raise IOError('An unexpected io error occured!')
            if error == TypeError():
                raise TypeError("An unexpected type error uccured!")
            if error == FileNotFoundError():
                raise FileNotFoundError("File not found error!")
        return []
