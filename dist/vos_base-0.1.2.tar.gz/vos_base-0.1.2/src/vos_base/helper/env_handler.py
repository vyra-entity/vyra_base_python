


class EnvHandler:
    """
    Class to handle the environment variables for the project.
    """

    def __init__(self):
        """
        Initialize the EnvHandler class.
        """
        self.env = {}

    def load_env(self, env_file: str):
        """
        Load the environment variables from a file.

        Args:
            env_file (str): Path to the environment file.
        """
        with open(env_file, "r") as f:
            for line in f:
                key, value = line.strip().split("=")
                self.env[key] = value