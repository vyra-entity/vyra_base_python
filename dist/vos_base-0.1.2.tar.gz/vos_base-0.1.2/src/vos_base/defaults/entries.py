from __future__ import annotations

from typing import Any
from datetime import datetime
from dataclasses import dataclass
from uuid import UUID

from enum import Enum
from re import DEBUG

class AvailableModuleEntry:
    pass


@dataclass(slots=True)
class ErrorEntry:
    """ Contains the database responses.

        Primitive Python object that stores the object values.
    """
    error_code: str
    module_id: str
    date: datetime
    type: Any
    description: str=''
    solution: str=''
    miscellaneous: str=''
    


class NewsFeedEntry(dict):
    """ News feed entry object. 
       
        Object that writes informational data to the graphical user interface.
        Makes use of the memory saving __slots__. 
    """
    __slots__ = (
        'level', 
        'message', 
        'timestamp', 
        'uuid', 
        'module_name', 
        'module_template'
        'type'
    )
    def __init__(
            self, 
            level: NewsFeedEntry.MESSAGE_TYPE, 
            message: str, 
            timestamp: datetime, 
            uuid: UUID, 
            module_name: str,
            module_template: str,
            type: Any
        ) -> None:

        self.message: NewsFeedEntry.Body = self.Body(level, message)
        self.timestamp: datetime = timestamp
        self.uuid: UUID = uuid
        self.module_name: str = module_name
        self.module_template: str = module_template
        self.type: Any = type


    class MESSAGE_TYPE(Enum):
        """ Enum for the message type. """
        ACTION = 'action'
        INFO = 'info'
        DEBUG = 'debug'
        WARNING = 'warning'
        HINT = 'hint'
    
    class Body:
        """ Message body object. """
        __slots__ = ('level', 'message')
        def __init__(self, level: NewsFeedEntry.MESSAGE_TYPE, message: str) -> None:
            self.level: NewsFeedEntry.MESSAGE_TYPE = level
            self.message: str = message


@dataclass(slots=True)
class PullRequestEntry:
    """ Contains the database responses.

        Primitive Python object that stores the object values.
    """
    uuid: str
    ack_by_user: str
    ack_on_date: str 
    request_structure: str
    request_on_date: str 
    request_description: str 
    response: str
    request_action:str 
    request_action_args: list 
    module_id: str
    color:int
    type: Any


@dataclass(repr=True, slots=True)
class StateEntry:
    """ Contains the database responses.

        Primitive Python object that stores the object values.
        Makes use of the memory saving __slots__.
    """
    previous: str
    current: str 
    module_uuid: UUID
    module_name: str
    timestamp: datetime
    type: Any

@dataclass(slots=True)
class ModuleEntry:
    """ Contains the module information.

        Primitive Python object that stores the object values.
        Makes use of the memory saving __slots__.
    """
    uuid: UUID
    name: str
    template: str
    description: str
    version: str
    